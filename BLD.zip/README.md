Bilibili List Download Extention

下载b站视频系列视频信息的插件, 方便对于视频学习进行时间规划

